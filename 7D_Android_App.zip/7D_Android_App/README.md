# 7D Android App (Starter MVP)

A Kotlin + Jetpack Compose starter app named **7D**.

## Included in this prototype
- Home screen and service categories
- Salon services with demo booking requests
- Grocery products and quantity controls
- Cart quantity management and total calculation
- Bottom navigation: Home, Explore, Cart, Bookings
- Simple responsive Material 3 UI

## Important limitations
This is a runnable **front-end prototype**, not a production-ready marketplace.
- No user authentication yet
- No cloud database or persistent storage
- No real salon directory or product inventory
- Checkout does not create an order or take payment
- Booking requests are stored in memory and reset when the app restarts
- Automotive and Education are placeholders

Do not use real customer, payment, or health information in this demo.

## Open in Android Studio
1. Download and unzip `7D_Android_App.zip`.
2. Open Android Studio.
3. Choose **Open** and select the extracted `7D_Android_App` folder.
4. Allow Gradle sync to finish. Use JDK 17.
5. Install Android SDK Platform 35 if Android Studio asks.
6. Select an emulator or connect an Android phone with USB debugging enabled.
7. Press **Run**.

If Android Studio suggests a compatible Gradle/Android Gradle Plugin update, accept its recommended stable version if sync fails.

## Upload to GitHub
1. Create a new repository named `7D`.
2. In Android Studio, use **Git > Enable Version Control Integration > Git** if needed.
3. Commit the project files.
4. Use **Git > GitHub > Share Project on GitHub**, or upload the folder using GitHub's website.

Never commit API keys, passwords, signing keys, or private customer data.

## Next production steps
1. Add a backend such as Firebase or Supabase.
2. Implement authentication and role permissions.
3. Store salons, services, products, appointments, cart, and orders in the database.
4. Add booking availability checks to prevent double booking.
5. Add privacy/security rules and tests.
6. Integrate a compliant payment provider only after backend validation.
7. Test on real devices before release.
