package com.sevend.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF172033)
private val Purple = Color(0xFF6C4CF1)
private val Pale = Color(0xFFF5F4FA)
private val Green = Color(0xFF1B8C65)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SevenDApp() }
    }
}

data class ServiceCategory(val name: String, val emoji: String, val subtitle: String)
data class ShopProduct(val id: Int, val name: String, val unit: String, val price: Int, val emoji: String)
data class SalonService(val name: String, val duration: String, val price: Int, val emoji: String)

private val categories = listOf(
    ServiceCategory("Salon", "💇", "Hair & beauty"),
    ServiceCategory("Grocery", "🛒", "Daily essentials"),
    ServiceCategory("Automotive", "🚗", "Vehicle care"),
    ServiceCategory("Education", "📚", "Learn & grow")
)
private val products = listOf(
    ShopProduct(1, "Fresh Apples", "500 g", 99, "🍎"),
    ShopProduct(2, "Bananas", "6 pieces", 49, "🍌"),
    ShopProduct(3, "Fresh Milk", "1 litre", 65, "🥛"),
    ShopProduct(4, "Tomatoes", "500 g", 35, "🍅"),
    ShopProduct(5, "Bread", "1 pack", 40, "🍞"),
    ShopProduct(6, "Spinach", "1 bunch", 25, "🥬")
)
private val salonServices = listOf(
    SalonService("Classic Haircut", "30 min", 199, "✂️"),
    SalonService("Beard Styling", "20 min", 99, "🧔"),
    SalonService("Hair Spa", "45 min", 499, "🧖"),
    SalonService("Facial Care", "40 min", 399, "✨")
)

@Composable
fun SevenDApp() {
    var selectedTab by remember { mutableStateOf("Home") }
    var selectedCategory by remember { mutableStateOf("Salon") }
    var cart by remember { mutableStateOf(mapOf<Int, Int>()) }
    var bookingMessage by remember { mutableStateOf<String?>(null) }
    var showBookings by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            secondary = Green,
            background = Pale,
            surface = Color.White,
            onPrimary = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Pale,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Explore", "Cart", "Bookings").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = {
                                selectedTab = tab
                                showBookings = tab == "Bookings"
                            },
                            icon = {
                                Text(
                                    when (tab) {
                                        "Home" -> "⌂"
                                        "Explore" -> "⌕"
                                        "Cart" -> "🛒"
                                        else -> "▣"
                                    },
                                    fontSize = 19.sp
                                )
                            },
                            label = { Text(if (tab == "Cart" && cart.values.sum() > 0) "Cart (${cart.values.sum()})" else tab) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                "Cart" -> CartScreen(
                    modifier = Modifier.padding(padding),
                    cart = cart,
                    onChangeQty = { id, qty ->
                        cart = if (qty <= 0) cart - id else cart + (id to qty)
                    }
                )
                "Bookings" -> BookingsScreen(
                    modifier = Modifier.padding(padding),
                    message = bookingMessage
                )
                "Explore" -> ExploreScreen(
                    modifier = Modifier.padding(padding),
                    selectedCategory = selectedCategory,
                    onSelectCategory = { selectedCategory = it },
                    cart = cart,
                    onChangeQty = { id, qty ->
                        cart = if (qty <= 0) cart - id else cart + (id to qty)
                    },
                    onBook = { service ->
                        bookingMessage = "$service — booking request created (demo)."
                        selectedTab = "Bookings"
                    }
                )
                else -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onExplore = { selectedTab = "Explore"; showBookings = false },
                    onCategory = { selectedCategory = it; selectedTab = "Explore" }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onExplore: () -> Unit,
    onCategory: (String) -> Unit
) {
    LazyColumn(modifier = modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Hello, welcome to", color = Color.Gray, fontSize = 13.sp)
                    Text("7D", color = Ink, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                }
                Box(Modifier.size(48.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
                    Text("7D", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().background(
                    brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Purple, Color(0xFF9B79FF))),
                    shape = RoundedCornerShape(24.dp)
                ).padding(22.dp)
            ) {
                Text("Everything you need,\none connected place.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Discover local services and book with ease.", color = Color.White.copy(alpha = .9f), fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onExplore, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple)) {
                    Text("Explore services")
                }
            }
        }
        item { Text("Popular categories", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink) }
        items(categories) { category ->
            Row(
                Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp))
                    .clickable { onCategory(category.name) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(54.dp).background(Pale, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text(category.emoji, fontSize = 28.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(category.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(category.subtitle, color = Color.Gray, fontSize = 13.sp)
                }
                Text("›", color = Purple, fontSize = 28.sp)
            }
        }
        item {
            Text("Built for your everyday needs.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
        }
    }
}

@Composable
private fun ExploreScreen(
    modifier: Modifier,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    cart: Map<Int, Int>,
    onChangeQty: (Int, Int) -> Unit,
    onBook: (String) -> Unit
) {
    LazyColumn(modifier = modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Explore", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text("Choose a category to get started.", color = Color.Gray)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { category ->
                    FilterChip(
                        selected = selectedCategory == category.name,
                        onClick = { onSelectCategory(category.name) },
                        label = { Text("${category.emoji} ${category.name}") }
                    )
                }
            }
        }
        if (selectedCategory == "Grocery") {
            item { Text("Fresh picks", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            items(products) { product ->
                ProductRow(product, quantity = cart[product.id] ?: 0, onAdd = { onChangeQty(product.id, (cart[product.id] ?: 0) + 1) }, onRemove = { onChangeQty(product.id, (cart[product.id] ?: 0) - 1) })
            }
        } else if (selectedCategory == "Salon") {
            item { Text("Salon services", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            items(salonServices) { service ->
                Row(
                    Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(54.dp).background(Pale, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Text(service.emoji, fontSize = 27.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(service.name, fontWeight = FontWeight.Bold)
                        Text("${service.duration} • ₹${service.price}", color = Color.Gray, fontSize = 13.sp)
                    }
                    Button(onClick = { onBook(service.name) }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                        Text("Book")
                    }
                }
            }
        } else {
            item {
                Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(20.dp)) {
                    Text(categories.firstOrNull { it.name == selectedCategory }?.emoji ?: "🌟", fontSize = 32.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("$selectedCategory services", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("This section is a starter demo. You can add real listings and booking workflows next.", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun ProductRow(product: ShopProduct, quantity: Int, onAdd: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(66.dp).background(Pale, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text(product.emoji, fontSize = 32.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(product.name, fontWeight = FontWeight.Bold)
            Text(product.unit, color = Color.Gray, fontSize = 12.sp)
            Text("₹${product.price}", color = Purple, fontWeight = FontWeight.ExtraBold)
        }
        if (quantity == 0) {
            Button(onClick = onAdd, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) { Text("Add") }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallButton("−", onRemove)
                Text("$quantity", modifier = Modifier.padding(horizontal = 10.dp), fontWeight = FontWeight.Bold)
                SmallButton("+", onAdd)
            }
        }
    }
}

@Composable
private fun SmallButton(label: String, onClick: () -> Unit) {
    Box(Modifier.size(30.dp).background(Purple, RoundedCornerShape(8.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun CartScreen(modifier: Modifier, cart: Map<Int, Int>, onChangeQty: (Int, Int) -> Unit) {
    val selected = products.filter { (cart[it.id] ?: 0) > 0 }
    val total = selected.sumOf { it.price * (cart[it.id] ?: 0) }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Your Cart", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Spacer(Modifier.height(14.dp))
        if (selected.isEmpty()) {
            Text("Your cart is empty. Explore Grocery and add products.", color = Color.Gray)
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(selected) { product ->
                    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(product.emoji, fontSize = 28.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold)
                            Text("₹${product.price} × ${cart[product.id]}", color = Color.Gray)
                        }
                        SmallButton("−") { onChangeQty(product.id, (cart[product.id] ?: 0) - 1) }
                        Text("${cart[product.id]}", modifier = Modifier.padding(horizontal = 8.dp))
                        SmallButton("+") { onChangeQty(product.id, (cart[product.id] ?: 0) + 1) }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Total: ₹$total", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { /* Demo only: real checkout requires backend/payment integration */ }, modifier = Modifier.fillMaxWidth()) {
                Text("Checkout (demo)")
            }
            Text("Demo only — no order or payment is submitted.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun BookingsScreen(modifier: Modifier, message: String?) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("My Bookings", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Spacer(Modifier.height(14.dp))
        if (message == null) {
            Text("No bookings yet. Explore Salon and tap Book on a service.", color = Color.Gray)
        } else {
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(message, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Status: Demo request", color = Green, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Note: bookings are stored only in app memory in this prototype.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
